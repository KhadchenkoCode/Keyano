package org.example;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

public class Main {

    public static long launchStart;
    public static void main(String[] args) throws LineUnavailableException {

        launchStart = System.currentTimeMillis();
        new InputListener();



    }

    public static void playFrequency(double frequency, int durationMs) throws LineUnavailableException {
        float sampleRate = 44100;
        byte[] buffer = new byte[(int) (sampleRate * durationMs / 1000)];

        for (int i = 0; i < buffer.length; i++) {
            double angle = 2.0 * Math.PI * frequency * i / sampleRate;
            buffer[i] = (byte) (Math.sin(angle) * 127);
        }

        AudioFormat format = new AudioFormat(sampleRate, 8, 1, true, false);
        SourceDataLine line = AudioSystem.getSourceDataLine(format);
        line.open(format);
        line.start();
        line.write(buffer, 0, buffer.length);
        line.drain();
        line.close();
    }

    public static void playFrequencyWithOvertones(double baseFreq, int durationMs) throws LineUnavailableException {
        float sampleRate = 44100;
        int numSamples = (int) (sampleRate * durationMs / 1000);
        byte[] buffer = new byte[numSamples];

        for (int i = 0; i < numSamples; i++) {
            double time = i / sampleRate;

            // Fundamental and overtones (basic additive synthesis)
            double wave =
                    1.0 * Math.sin(2 * Math.PI * baseFreq * time) +                   // Fundamental
                            0.25 * Math.sin(2 * Math.PI * baseFreq * 2 * time) +      // 1st overtone
                            0.125 * Math.sin(2 * Math.PI * baseFreq * 4 * time);     // 1st overtone


            // Scale to byte range
            buffer[i] = (byte) (wave * 127);
        }

        AudioFormat format = new AudioFormat(sampleRate, 8, 1, true, false);
        SourceDataLine line = AudioSystem.getSourceDataLine(format);
        line.open(format);
        line.start();
        line.write(buffer, 0, buffer.length);
        line.drain();
        line.close();
    }

}