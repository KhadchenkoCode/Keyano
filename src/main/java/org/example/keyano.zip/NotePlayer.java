package org.example;

import javax.sound.sampled.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NotePlayer {

    private final Map<Integer, Boolean> activeNotes = new ConcurrentHashMap<>();
    private SourceDataLine line;
    private double phase = 0.0;

    private double createWave(double time) {
        double waveRet = 0;
        for (Integer key : activeNotes.keySet()) {
            if (Boolean.TRUE.equals(activeNotes.get(key))) {
                double baseFreq = key;
                double wave =
                        1.0 * Math.sin(2 * Math.PI * baseFreq * time) +
                                0.25 * Math.sin(2 * Math.PI * baseFreq * 2 * time) +
                                0.125 * Math.sin(2 * Math.PI * baseFreq * 4 * time);
                waveRet += wave;
            }
        }
        return Math.max(-1.0, Math.min(1.0, waveRet));
    }

    public void playAllActiveNotes() {
        float sampleRate = 44100;
        int durationMs = 5;
        int numSamples = (int) (sampleRate * durationMs / 1000);
        byte[] buffer = new byte[numSamples * 2]; // 16-bit = 2 bytes

        for (int i = 0; i < numSamples; i++) {
            double wave = createWave(phase);
            phase += 1.0 / sampleRate;

            short sample = (short) (wave * Short.MAX_VALUE); // 16-bit
            buffer[2 * i]     = (byte) (sample & 0xFF);       // low byte
            buffer[2 * i + 1] = (byte) ((sample >> 8) & 0xFF); // high byte
        }

        line.write(buffer, 0, buffer.length);
    }

    public void noteThreadLoop() {
        float sampleRate = 44100;
        int frameSize = 2; //2 bytes
        int bufferMs = 10;
        int bufferSize = (int) (sampleRate * bufferMs / 1000) * frameSize;

        AudioFormat format = new AudioFormat(sampleRate, 16, 1, true, false); // 16-bit PCM
        try {
            line = AudioSystem.getSourceDataLine(format);
            line.open(format, bufferSize);
            line.start();
        } catch (LineUnavailableException e) {
            throw new RuntimeException("Failed to initialize audio line", e);
        }

        while (true) {
            playAllActiveNotes();
        }
    }

    public void updateNoteStatus(int frequency, boolean activity) {
        activeNotes.put(frequency, activity);
    }
}