package org.example;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NoteMapper {


    static final double halftone = 1.05946309436;

    public  ArrayList<Integer> readFromString(String keys){
        ArrayList<Integer> ret = new ArrayList<>();
        for(int i= 0; i<keys.length(); i++){
            char c = keys.charAt(i);
            Integer k = keyCodeFromChar(c);
            ret.add(k);
        }
        return ret;
    }

    private  int keyCodeFromChar(char c){
        int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);

        return keyCode;

    }

    public static Map<Integer, Integer> chromaticFrequencies(List<Integer> keyCodes, int startingFrequency_hz) {
        Map<Integer, Integer> ret = new HashMap<Integer, Integer>();
        int frequency = startingFrequency_hz;
        for (int i = 0; i <keyCodes.size() ; i++) {
            Integer keyCode = keyCodes.get(i);
            ret.put(keyCode, frequency);
            frequency*=halftone;
        }
        return ret;
    }

}
